function SendNotification(msg, type)
    type = type or "info"

    if GetResourceState("mythic_notify") == "started" then
        exports['mythic_notify']:SendAlert(type, msg, 3000)
    elseif GetResourceState("okokNotify") == "started" then
        exports['okokNotify']:Alert("Tire Slash", msg, 3000, type)
    elseif GetResourceState("pNotify") == "started" then
        exports['pNotify']:SendNotification({
            text = msg,
            type = type,
            timeout = 3000
        })
    else
        SetNotificationTextEntry("STRING")
        AddTextComponentString(msg)
        DrawNotification(false, false)
    end
end