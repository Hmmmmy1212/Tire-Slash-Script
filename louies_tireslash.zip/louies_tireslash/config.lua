Config = {}

Config.RequiredWeapon = "WEAPON_KNIFE"  
Config.DistanceCheck = 3.0        
Config.Cooldown = 5000                  
Config.AlertPolice = false             
Config.PoliceJobName = "police"        
Config.MinimumPolice = 0              

Config.SlashAnimation = {
    dict = "melee@knife@streamed_core",
    anim = "plyr_takedown_front_slap",
    duration = 2000
}

Config.NotificationType = "default"  
Config.CustomNotifyEvent = "customNotification"

Config.Keybind = "G"                  
Config.KeybindLabel = "Slash Tire"     

Config.Debug = false

Config.Messages = {
    no_knife = "You need a knife to slash tires!",
    cooldown = "You can't slash tires again so soon!",
    police_notify = "Tire slashing reported",
    slashed = "You slashed the tire!",
    knife_equipped = "~g~Knife equipped: Press ~w~%s~g~ to slash tires"
}