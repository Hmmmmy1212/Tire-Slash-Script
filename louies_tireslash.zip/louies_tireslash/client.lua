local slashing = false
local lastSlash = 0
local showingHelp = false

function LoadAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Citizen.Wait(5)
    end
end

function HasKnifeInHand()
    local ped = PlayerPedId()
    local currentWeapon = GetSelectedPedWeapon(ped)

    local knifeHashes = {
        GetHashKey("WEAPON_KNIFE"),
        GetHashKey("WEAPON_SWITCHBLADE"),
        GetHashKey("WEAPON_DAGGER"),
        GetHashKey("WEAPON_HATCHET"),
        GetHashKey("WEAPON_BOTTLE")
    }
    
    for _, hash in ipairs(knifeHashes) do
        if currentWeapon == hash then
            return true
        end
    end
    
    return false
end

function ShowNotification(msg, type)
    type = type or "info"

    SetNotificationTextEntry("STRING")
    AddTextComponentString(msg)
    DrawNotification(false, false)

    if Config.Debug then
        print("[TireSlash] " .. msg)
    end
end

function PlaySlashAnimation()
    LoadAnimDict(Config.SlashAnimation.dict)
    
    local ped = PlayerPedId()
    TaskPlayAnim(
        ped,
        Config.SlashAnimation.dict,
        Config.SlashAnimation.anim,
        8.0,
        -8.0,
        Config.SlashAnimation.duration,
        15,
        1.0,
        false, false, false
    )
    
    Citizen.Wait(Config.SlashAnimation.duration)
    ClearPedTasks(ped)
end

function GetClosestVehicle()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local vehicles = GetGamePool("CVehicle")
    local closestDist, closestVehicle = nil, nil
    
    for _, vehicle in pairs(vehicles) do
        local vehPos = GetEntityCoords(vehicle)
        local dist = #(pos - vehPos)
        
        if dist < Config.DistanceCheck then
            if not closestDist or dist < closestDist then
                closestDist = dist
                closestVehicle = vehicle
            end
        end
    end
    
    return closestVehicle, closestDist
end

function GetClosestTire(vehicle)
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local tirePositions = {
        {bone = "wheel_lf", index = 0},
        {bone = "wheel_rf", index = 1},
        {bone = "wheel_lr", index = 2},
        {bone = "wheel_rr", index = 3}
    }
    
    local closestDist, closestIndex = nil, nil
    
    for _, tire in ipairs(tirePositions) do
        local boneIndex = GetEntityBoneIndexByName(vehicle, tire.bone)
        if boneIndex ~= -1 then
            local tirePos = GetWorldPositionOfEntityBone(vehicle, boneIndex)
            local dist = #(pos - tirePos)
            
            if dist < 1.5 then
                if not closestDist or dist < closestDist then
                    closestDist = dist
                    closestIndex = tire.index
                end
            end
        end
    end
    
    return closestIndex
end

function SlashTire()
    if slashing then return end

    local currentTime = GetGameTimer()
    if currentTime - lastSlash < Config.Cooldown then
        ShowNotification(Config.Messages.cooldown, "error")
        return
    end

    if not HasKnifeInHand() then
        ShowNotification(Config.Messages.no_knife, "error")
        return
    end

    local vehicle, distance = GetClosestVehicle()
    if not vehicle or distance > Config.DistanceCheck then
        return
    end
    
    slashing = true

    local tireIndex = GetClosestTire(vehicle)
    if not tireIndex then
        slashing = false
        return
    end

    PlaySlashAnimation()

    SetVehicleTyreBurst(vehicle, tireIndex, true, 1000.0)

    ShowNotification(Config.Messages.slashed, "success")

    if Config.AlertPolice then
        local vehicleCoords = GetEntityCoords(vehicle)
        TriggerServerEvent("tire-slash:alertPolice", {
            x = vehicleCoords.x,
            y = vehicleCoords.y,
            z = vehicleCoords.z
        })
    end

    TriggerServerEvent("tire-slash:slashedTire", VehToNet(vehicle), tireIndex)
 
    lastSlash = GetGameTimer()
    slashing = false
end

RegisterKeyMapping("slash", Config.KeybindLabel, "keyboard", Config.Keybind)

RegisterCommand("slash", function()
    SlashTire()
end, false)

function DrawHelpText()
    if showingHelp then
        SetTextComponentFormat("STRING")
        AddTextComponentString(Config.Messages.knife_equipped:format(Config.Keybind))
        DisplayHelpTextFromStringLabel(0, false, true, -1)
    end
end

Citizen.CreateThread(function()
    while true do
        local ped = PlayerPedId()

        if not IsPedInAnyVehicle(ped, false) then
            local vehicle = GetClosestVehicle()
            local hasKnife = HasKnifeInHand()

            if vehicle and hasKnife then
                showingHelp = true
                DrawHelpText()

                local vehCoords = GetEntityCoords(vehicle)
                local pedCoords = GetEntityCoords(ped)
                local distance = #(pedCoords - vehCoords)
                
                if distance < 1.5 and IsControlJustPressed(0, 51) then -- E key
                    SlashTire()
                end
            else
                showingHelp = false
            end
        else
            showingHelp = false
        end
        
        Citizen.Wait(0)
    end
end)

if Config.Debug then
    RegisterCommand("debugtire", function()
        local vehicle = GetClosestVehicle()
        if vehicle then
            print("Vehicle found: " .. GetEntityModel(vehicle))
            print("Distance: " .. #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(vehicle)))
        else
            print("No vehicle found nearby")
        end
    end, false)
end