fx_version 'cerulean'
game 'gta5'
author 'Louie'
description 'Standalone Tire Slashing Script - Made By https://discord.gg/6GDps7XzTm'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}