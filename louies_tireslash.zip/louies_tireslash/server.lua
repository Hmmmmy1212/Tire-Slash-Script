local cooldowns = {}

RegisterServerEvent("tire-slash:alertPolice")
AddEventHandler("tire-slash:alertPolice", function(coords)
    local src = source
    
    if not Config.AlertPolice then return end

    local players = GetPlayers()
    
    for _, playerId in ipairs(players) do
        local playerIdNum = tonumber(playerId)
        
        TriggerClientEvent("tire-slash:policeAlert", playerIdNum, coords)
    end

    print(("[TireSlash] Police alerted by player %s at location: %s"):format(src, json.encode(coords)))
end)

RegisterServerEvent("tire-slash:slashedTire")
AddEventHandler("tire-slash:slashedTire", function(netId, tireIndex)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)

    if cooldowns[identifier] and os.time() - cooldowns[identifier] < (Config.Cooldown / 1000) then
        return
    end
    
    cooldowns[identifier] = os.time()

    print(("[TireSlash] Player %s slashed tire on vehicle %s (tire index: %s)"):format(
        identifier, netId, tireIndex
    ))
end)

RegisterServerEvent("tire-slash:getCooldown")
AddEventHandler("tire-slash:getCooldown", function(cb)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)
    
    if cooldowns[identifier] then
        local remaining = (Config.Cooldown / 1000) - (os.time() - cooldowns[identifier])
        cb(remaining > 0 and remaining or 0)
    else
        cb(0)
    end
end)

RegisterCommand("resettirecooldown", function(source, args)
    if source ~= 0 then 
        print("This command can only be run from server console")
        return
    end
    
    cooldowns = {}
    print("[TireSlash] All cooldowns reset")
end, true)